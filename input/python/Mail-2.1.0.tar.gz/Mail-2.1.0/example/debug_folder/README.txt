When you run the ``debug_folder.conf`` example, this is where mails that are redirected will be stored.

You can run it like this:

::

    python bag_mail.py debug_folder.conf
