The test can be run like this:

::

    python test_mail.py

You will be prompted for email addresses to use in the test and then a selectio
of emails will be sent using attatchments, html and plain text.
