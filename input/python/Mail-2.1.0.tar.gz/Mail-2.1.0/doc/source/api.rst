API Documentation
+++++++++++++++++
   
.. automodule:: mail 
   :members:
   :undoc-members:
